import React from "react";
import Sidebar from "../../components/Sidebar";

function Dashboard() {
  return <>
  
  <Sidebar/>
    </>;
}

export default Dashboard;
