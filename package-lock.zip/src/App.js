'use strict';
import RouterApp from "./routes/Router.jsx";

function App() {
    return(
        <RouterApp />
    );
}

export default App